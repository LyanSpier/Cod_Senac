from pathlib import Path
import os

BASE_DIR  = path